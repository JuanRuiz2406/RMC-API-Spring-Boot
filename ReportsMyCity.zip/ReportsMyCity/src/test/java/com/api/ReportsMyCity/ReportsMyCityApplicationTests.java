package com.api.ReportsMyCity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportsMyCityApplicationTests {

	@Test
	void contextLoads() {
	}

}
